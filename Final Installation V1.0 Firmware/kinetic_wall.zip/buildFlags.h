#pragma once

// BUILD
// #define INVERT_SENSORS true
// #define SKIP_HOMING

// DEBUG FLAGS:
#define DEBUG_CONFIG
// #define DEBUG_HOMING
// #define DEBUG_ANIMATIONS
// #define DEBUG_MOTORCONTROL